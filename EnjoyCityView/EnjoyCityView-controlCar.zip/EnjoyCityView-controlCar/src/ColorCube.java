import javafx.scene.Node;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.MeshView;
import javafx.scene.shape.TriangleMesh;

/**
 * Recreate a version of the Java3D color cube
 * 
 * Based on @author mike slattery
 *
 */

public class ColorCube {
	MeshView mv;
	
	public ColorCube(double size)
	{
		TriangleMesh mesh = new TriangleMesh();
		
		// create texture map
		// Use palette trick from jpereda - FXyz
		Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW,
				Color.WHITE, Color.PURPLE};
		
		WritableImage palette = new WritableImage(colors.length,1);
		PixelWriter pw = palette.getPixelWriter();
		
		for (int x = 0; x < colors.length; x++)
		{
			pw.setColor(x,0,colors[x]);
			mesh.getTexCoords().addAll((x+0.5f)/colors.length, 0.5f);
		}
		PhongMaterial mat = new PhongMaterial();
		mat.setDiffuseMap(palette);
		
		// define vertices
		float d = (float)size/2;
		mesh.getPoints().addAll(
		        -d,    -d,    -d,
		        d,    -d,    -d,
		        d,    d,    -d,
		        -d,    d,    -d,
		        -d,    -d,    d,
		        d,    -d,    d,
		        d,    d,    d,
		        -d,    d,    d
		    );
		
		// define faces
		mesh.getFaces().addAll(
		        0,0,  2,0,  1,0,          // Front face
		        0,0,  3,0,  2,0,
		        4,1,  3,1,  0,1,          // Left face
		        4,1,  7,1,  3,1,
		        4,2,  5,2,  6,2,          // Back face
		        4,2,  6,2,  7,2,
		        1,3,  6,3,  5,3,          // Right face
		        1,3,  2,3,  6,3,
		        2,4,  3,4,  7,4,          // Bottom face
		        2,4,  7,4,  6,4,
		        0,5,  1,5,  4,5,           // Top face
		        1,5,  5,5,  4,5
		    ); 
		mesh.getFaceSmoothingGroups().addAll(
				1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6);
		
		mv = new MeshView(mesh);
		mv.setMaterial(mat);
	}
	
	public Node getNode()
	{
		return mv;
	}
}
