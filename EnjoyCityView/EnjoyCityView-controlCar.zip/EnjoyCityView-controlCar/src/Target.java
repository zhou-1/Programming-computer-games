import java.util.ArrayList;
import java.util.Iterator;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.geometry.Bounds;
import javafx.geometry.Point3D;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.shape.Sphere;
import javafx.util.Duration;

public class Target extends Group{
	final int NPANELS = 1;
	final double RADIUS = 20;
	ArrayList<Box> panels = new ArrayList<Box>(NPANELS);
	
	public Target() {
		super();
		final PhongMaterial whiteMaterial = new PhongMaterial();
        whiteMaterial.setDiffuseColor(Color.WHITE);
        whiteMaterial.setSpecularColor(Color.WHITE);
        Box s = new Box(RADIUS, RADIUS, 10);
        s.setMaterial(whiteMaterial);
        
        panels.add(s);
        
        s.setTranslateX(150);
        s.setTranslateY(0);
        s.setTranslateZ(0);
        
        getChildren().addAll(s);
        
	}
	
	//detect for intersect
	public boolean isTouching(Car b)
	{
		Bounds bb = b.localToScene(b.getBoundsInLocal());
		Iterator<Box> iter = panels.iterator();
		while (iter.hasNext())
		{
			Box t = iter.next();
			if(t.getBoundsInLocal().intersects(t.sceneToLocal(bb))){
				getChildren().remove(t);
				iter.remove();
				return true;
			}
		}
		return false;
	}
		
}
