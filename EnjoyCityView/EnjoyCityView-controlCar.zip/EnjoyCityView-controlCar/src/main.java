import java.io.IOException;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Point3D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.shape.Sphere;
import javafx.scene.shape.TriangleMesh;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.DrawMode;
import javafx.scene.shape.Mesh;
import javafx.scene.shape.MeshView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.text.*;
import javafx.scene.media.AudioClip;

import javafx.scene.*; //in case that we miss something we don't pay attention to

/*
 * Basic 3D game
 * for assignment 9 in COSC 3550
 * Zhou Shen
 * Control red sephere car to move freely in the world
 * the goal is touching the white box in front of the car
 * You can use up, left and right key to control the car
 * Once you touch, the crash audio will play and shows you got one score and won
 * 
 * Enjoy good city view during the game
 * Grey buildings, different rotated cubes, basic object with AOI
 * and one colorful pyramid
 * 
 * Use construct 
 * Based on 3D shoot
 *
 * 
 */

public class main extends Application{
	
	final String appName = "City View";
	final int FPS = 30; // frames per second
	final static int WIDTH = 800;
	final static int HEIGHT = 600;
	final static int EDGE = 0;
	final double BOUND = 800;

	Group root;
	private PerspectiveCamera camera;
	//private Group cameraDolly;
	
	AudioClip crash;

	private final double cameraQuantity = 10.0;  //space for movement
	
	Car car;
	Target target;
	
	
	//Sprite scenery[];
	boolean boxDebug = false;
	
	// Global scale variable for bounding boxes
	public static float BBscale = 1.0f;
	
	//Font font = Font.font("TimesRoman", FontPosture.ITALIC, 20.0);
	
	
	
	
	/**
	 * Set up initial data structures/values
	 */
	private void constructWorld(Group root) {
		//Lighting
    	AmbientLight light = new AmbientLight(Color.rgb(100,100,100));
    	root.getChildren().add(light);
    	
    	PointLight pl = new PointLight();
    	pl.setTranslateX(-200);
    	pl.setTranslateY(-200);
    	pl.setTranslateZ(-100);
    	root.getChildren().add(pl);
 
    	// below is for white text demo show
    	Text t = new Text(10, 50, "Enjoy Amazing City View");
    	t.setFont(new Font(20));
    	t.setFill(Color.WHITE);	
    	t.setTranslateX(-110);
    	t.setTranslateY(-240);
    					
    	root.getChildren().add(t);
    	
    		
    	/*
    	* Below are for 3D objects
    	*/
    	//
    	
    	// Temp axes for reference
    	//good for reference
    	/*
    	final PhongMaterial greenMaterial = new PhongMaterial();
        greenMaterial.setDiffuseColor(Color.FORESTGREEN);
        greenMaterial.setSpecularColor(Color.LIMEGREEN);
        Box xAxis = new Box(200, 10, 10);
        xAxis.setMaterial(greenMaterial);	//x is green
        
        final PhongMaterial redMaterial = new PhongMaterial();
        redMaterial.setDiffuseColor(Color.RED);
        redMaterial.setSpecularColor(Color.ORANGE);
        Box yAxis = new Box(10, 200, 10);
        yAxis.setMaterial(redMaterial);		//y is red
        
        final PhongMaterial yellowMaterial = new PhongMaterial();
        yellowMaterial.setDiffuseColor(Color.YELLOW);
        yellowMaterial.setSpecularColor(Color.WHITE);
        Box zAxis = new Box(10, 10, 200);
        zAxis.setMaterial(yellowMaterial);		//z is yellow
        
        root.getChildren().addAll(xAxis, yAxis, zAxis);
        */
    	
    	/*
		 * Left up corner
		 */
		//box building 1 - Grey
		final PhongMaterial blueMaterial = new PhongMaterial();
		blueMaterial.setDiffuseColor(Color.GREY);
		blueMaterial.setSpecularColor(Color.WHITE);
		Box box = new Box(60, 50, 140);
		box.setMaterial(blueMaterial);
		// box.setDrawMode(DrawMode.LINE);

		box.setTranslateX(-150);
		box.setTranslateY(-120);
		box.setTranslateZ(0);
		
		root.getChildren().addAll(box);
    	
		//another short building 2
		final PhongMaterial greyMaterial = new PhongMaterial();
		greyMaterial.setDiffuseColor(Color.GREY);
		greyMaterial.setSpecularColor(Color.WHITE);
		Box box1 = new Box(60, 50, 80);
		box1.setMaterial(greyMaterial);
		// box.setDrawMode(DrawMode.LINE);

		box1.setTranslateX(-80);
		box1.setTranslateY(-120);
		box1.setTranslateZ(30);  //bottom keep same to first one
		
		root.getChildren().addAll(box1);
    	

		/*
		 * Right up corner
		 * rotate cube
		 */
		// Insert a spinning color cube
		Node ccNode = new ColorCube(40).getNode();
		// Tilt color cube
		Rotate r1 = new Rotate(45, Rotate.Z_AXIS);
		//Rotate r2 = new Rotate(45, Rotate.X_AXIS);
		ccNode.getTransforms().addAll(r1);
		// And spin it
		Group spinner = new Group();
		spinner.getChildren().add(ccNode);
		RotateTransition rt = new RotateTransition(Duration.millis(4000), spinner);
		rt.setByAngle(360);
		rt.setAxis(Rotate.Y_AXIS);
		rt.setInterpolator(Interpolator.LINEAR);
		rt.setCycleCount(Animation.INDEFINITE);
		rt.setAutoReverse(false);
		rt.play();
		
		spinner.setTranslateX(180);
		spinner.setTranslateY(-120);
		spinner.setTranslateZ(0);
		
		spinner.setRotationAxis(Rotate.Z_AXIS);
		spinner.setRotate(90);
		
		root.getChildren().addAll(spinner);
		
		//another cube
		Node ccNode1 = new ColorCube(40).getNode();
		// Tilt color cube
		Rotate r2 = new Rotate(45, Rotate.X_AXIS);
		//Rotate r2 = new Rotate(45, Rotate.X_AXIS);
		ccNode1.getTransforms().addAll(r2);
		// And spin it
		Group spinner1 = new Group();
		spinner1.getChildren().add(ccNode1);
		RotateTransition rt1 = new RotateTransition(Duration.millis(4000), spinner1);
		rt1.setByAngle(360);
		rt1.setAxis(Rotate.Y_AXIS);
		rt1.setInterpolator(Interpolator.LINEAR);
		rt1.setCycleCount(Animation.INDEFINITE);
		rt1.setAutoReverse(true);
		rt1.play();
		
		spinner1.setTranslateX(100);
		spinner1.setTranslateY(-120);
		spinner1.setTranslateZ(0);
		
		spinner1.setRotationAxis(Rotate.Z_AXIS);
		spinner1.setRotate(90);
		
		root.getChildren().addAll(spinner1);
		
		
		/*
		 * right bottom corner
		 * fancy pyramidMesh
		 * 
		 */
		TriangleMesh pyramidMesh = new TriangleMesh();
		// define (a trivial) texture map
		pyramidMesh.getTexCoords().addAll(
				0.5f, 0,
				0, 0.5f,
				1, 0.5f,
				0, 1,
				1, 1
				);
		// define vertices
		float h = 60;                    // Height
		float s = 100;                    // Base hypotenuse
		pyramidMesh.getPoints().addAll(
				0,    0,    0,            // Point 0 - Top
				0,    h,    -s/2,         // Point 1 - Front
				-s/2, h,    0,            // Point 2 - Left
				s/2,  h,    0,            // Point 3 - Right
				0,    h,    s/2           // Point 4 - Back
				);
		// define faces
		pyramidMesh.getFaces().addAll(
				0,0,  2,1,  1,2,          // Front left face
				0,0,  1,1,  3,1,          // Front right face
				0,0,  3,1,  4,2,          // Back right face
				0,0,  4,1,  2,2,          // Back left face
				4,1,  1,4,  2,2,          // Bottom left face
				4,1,  3,3,  1,4           // Bottom right face
				); 
		pyramidMesh.getFaceSmoothingGroups().addAll(1, 2, 3, 4, 5, 5);			//five colors in the image
		MeshView pyramid = new MeshView(pyramidMesh);
		//pyramid.setDrawMode(DrawMode.LINE);
		final PhongMaterial pyrMaterial = new PhongMaterial();
		pyrMaterial.setDiffuseMap(new Image("sample.png"));
		pyrMaterial.setSpecularColor(Color.WHITE);
		pyramid.setMaterial(pyrMaterial);
		pyramid.setTranslateX(150);
		pyramid.setTranslateY(90);
		pyramid.setTranslateZ(0);
		
		pyramid.setRotationAxis(Rotate.X_AXIS);
		pyramid.setRotate(90);
				
		root.getChildren().add(pyramid);
		
		
		/*
		 * Left bottom object
		 */
		// easy object created by myself
		//object 
		ObjView drvr = new ObjView();
		try {
			drvr.load(ClassLoader.getSystemResource("easy.obj").toString());
		} catch (IOException e) {
			System.out.println("Trouble loading model");
			e.printStackTrace();
		}
		Group droid = drvr.getRoot();
		droid.setScaleX(50);
		droid.setScaleY(50);
		droid.setScaleZ(-80);
		droid.setTranslateX(-130);
		droid.setTranslateY(110);	
		
		root.getChildren().add(droid);
		
		/*
		 * 
		for (Node n:droid.getChildren())
		{
			MeshView mv = (MeshView) n;
			Mesh m = ((MeshView) n).getMesh();
			//mv.setDrawMode(DrawMode.LINE);
			System.out.println(n);
			System.out.println(m);
			TriangleMesh tm = (TriangleMesh) m;
			System.out.println("Faces: "+tm.getFaceElementSize());
			System.out.println(tm.getFaces() );
			System.out.println(tm.getFaceSmoothingGroups());
			System.out.println("Normals: "+tm.getNormalElementSize());
			System.out.println(tm.getNormals());
			System.out.println("Points: "+tm.getPointElementSize());
			System.out.println(tm.getPoints());
			System.out.println("TexCoords: "+tm.getTexCoordElementSize());
			System.out.println(tm.getTexCoords());
		}
		*/
		
		//target
		target = new Target();
		target.setTranslateX(80);
		root.getChildren().add(target);
		
		//moving objects
		car = new Car(-200);
		root.getChildren().add(car);
		
		crash = new AudioClip(ClassLoader.getSystemResource("recycle.wav").toString());
	}
	
	
	
	/*
	 * set handlers for moving the car
	 */
	void setHandlers(Scene scene)
	{
		scene.setOnKeyPressed(
			e -> {
				KeyCode c = e.getCode();
				switch (c) {
					case LEFT: car.setLeftKey(true);
								break;
					case RIGHT: car.setRightKey(true);
								break;
					case UP: car.setUpKey(true);
								break;
					default:
								break;
				}
			}
		);
		
		scene.setOnKeyReleased(
				e -> {
					KeyCode c = e.getCode();
					switch (c) {
						case LEFT: car.setLeftKey(false);
									break;
						case RIGHT: car.setRightKey(false);
									break;
						case UP: car.setUpKey(false);
									break;
						default:
									break;
					}
				}
			);
	}
	
	
	
	/**
	 *  Update variables for one time step
	 */
	public void update()
	{
		car.move();
		if (target.isTouching(car)){
			crash.play();
			Text t = new Text(10, 50, "One score, You Won!!!");
	    	t.setFont(new Font(30));
	    	t.setFill(Color.WHITE);	
	    	t.setTranslateX(-130);
	    	t.setTranslateY(-30);
	    					
	    	root.getChildren().add(t);
		}
	}
	
	
	@Override
	public void start(Stage theStage) {
		theStage.setTitle(appName);

		root = new Group();
		constructWorld(root);
		
		Scene scene = new Scene(root, WIDTH, HEIGHT, true);
        scene.setFill(Color.BLACK);
        camera = new PerspectiveCamera(true);
        camera.setNearClip(0.1);
        camera.setFarClip(10000.0);
        
        
        camera.setRotationAxis(Rotate.X_AXIS);
        camera.setRotate(0);			//-90
        Rotate rot = new Rotate();
        rot.setAngle(0);
		rot.setAxis(Rotate.Y_AXIS);
		camera.getTransforms().add(rot);
        camera.setTranslateX(0);
        camera.setTranslateY(0);
        camera.setTranslateZ(-800);
        //add on camera on scene  
        scene.setCamera(camera);
        
        setHandlers(scene);
		
		
		
		
		// Setup and start animation loop (Timeline)
		KeyFrame kf = new KeyFrame(Duration.millis(1000 / FPS),
				e -> {
					// update position
					update();
					// draw
				}
			);
		Timeline mainLoop = new Timeline(kf);
		mainLoop.setCycleCount(Animation.INDEFINITE);
		mainLoop.play();

		theStage.setScene(scene);
	    theStage.show();
		
	}
	
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
