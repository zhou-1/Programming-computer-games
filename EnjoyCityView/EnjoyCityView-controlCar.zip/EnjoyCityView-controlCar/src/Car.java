
import javafx.geometry.Point3D;
import javafx.scene.Group;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;


/*
 * Based on roomba
 * draw the animation for car
 */

public class Car extends Group{
	//round yellow car with eyes for direction indication
	
	double x,y,dir_angle; //position, rotation

	boolean upKey = false, leftKey = false, rightKey = false;
	
	final static int WIDTH = 20;
	final static int HEIGHT = 20;
	final static int SPEED = 4;

	double vx;
	double vy;
	
	
	// Set x1 as the middle of the car
	public Car(int x1){
		super();
		x = x1 - WIDTH/2;
		y = main.EDGE;
		dir_angle = Math.PI;
		
		//create the car
		final PhongMaterial car = new PhongMaterial();
		car.setDiffuseColor(Color.RED);
        car.setSpecularColor(Color.WHITE);
        Sphere s = new Sphere(WIDTH);
        s.setMaterial(car);
        
        s.setTranslateX(x);
        s.setTranslateY(y);
        s.setTranslateZ(0);
        
        getChildren().addAll(s);
        
        
		/*
		//create the car
		gc.setFill(Color.YELLOW);
		gc.fillOval(x, y, WIDTH, HEIGHT);
		
		//create an eye for the roomba
		// We use dir_angle to position the "eye"
		// First, get the center of the roomba:
		double cx = x + WIDTH/2;
		double cy = y + HEIGHT/2;
		// Then get the center of the eye:
		double ecx = cx + (WIDTH/2 - 10)*Math.cos(dir_angle);
		double ecy = cy + (HEIGHT/2 - 10)*Math.sin(dir_angle);
		//Draw eye
		gc.setFill(Color.RED);
		gc.fillOval(ecx - 10, ecy - 10, 20, 20);
		*/
		
		
	}
	
	//limit the car on the road
	public void move(){
		//move in one direction
		// We use trig to compute values for  vx and vy
		//   based on angle and speed
		vx = SPEED * Math.cos(dir_angle);
		vy = SPEED * Math.sin(dir_angle);
		//System.out.println(vx+","+vy);
		
		//use up key to control the car
		if(upKey) {
			setTranslateX(getTranslateX() + vx);
			setTranslateY(getTranslateY() + vy);
			//x += vx; 
			//y += vy;
			
		}
			
		

		//once click left or right key
		// these just affect angle
		if (leftKey)
			dir_angle -= 0.2;
		if (rightKey)
			dir_angle += 0.2;
	}
	
	// start the ball in mid-screen with a somewhat
	// random direction
	public void reset() {
		x = main.WIDTH/2;
		y = main.HEIGHT/4;

	}
	
	
	public void setUpKey(Boolean val) {
		upKey = val;
	}
	
	public void setLeftKey(Boolean val){
		leftKey = val;
	}

	public void setRightKey(Boolean val){
		rightKey = val;
	}

	// return the x-coord of middle of plane
	public int getLeft(){
		return (int)x;
	}

	public int getRight(){
		return (int)x+WIDTH;
	}
	
	
}
